/**
 * Created by nbaki
 */


Registrants = {
    params: null,

    init: function(params) {
    },
};
